# Neighborhood-Map
# THIS PROJECT AIME TO AHMED GAMAL

## How to run this app

- check your internet connection.
- open index.html in your browser.

## What is this ? 
this app is google map contain some locations you can move to any location and display some information about it by using this app . 
