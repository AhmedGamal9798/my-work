 function a(){
     var y="ahmed";
         z=123;
     var r="abotaleb";
          t=123;
    var x= document.getElementById("ab").value;
     var u =document.getElementById("v").value;
     if(x==y&&z==u||x==r||t==u )
        { 
            var log='<p class="login"><a href="4.html">Login</a></p>';
            document.getElementById("login").innerHTML=log;
            document.write(log);
        }
     
}